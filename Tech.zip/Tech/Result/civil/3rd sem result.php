<?php
mysql_connect("localhost","root","");
mysql_select_db(webs);
if(isset($_POST['submit']))
      $roll=$_POST['roll'];
if(mysql_query($result))


?>
<html>
<body>

<input type="submit" name="submit" value="PRINT THIS PAGE" onclick="window.print()" style="margin:20px 0px 0px 530px; ">

 <?php
    mysql_connect("localhost","root","");
    mysql_select_db("webs");
    $result=mysql_query("select * from cethird where roll=$roll;");
    ?>
    
<form method="post">
      <table border="1" height="700px"; align="center";>
          
             <?php
while($row=mysql_fetch_array($result))
        {
            ?>
                        
            



            <tr>
                  <td style="border:none;"><img src="logo.png" style="height:120px; width: 130px;"></td>
                  <td colspan="4" align="center" style="height: 60px; font-size: 25px; text-align: center; border:none; font-weight: bold;">AMBALIKA INSTITUTE OF PROFESSIONAL STUDIES  LUCKNOW<br>UTTAR PRADESH</td>
            
            </tr>

            <tr>
                  <td colspan="5" align="center" style="font-weight: bold;">THIRD SEMESTER SESSIONAL RESULT JULY-2022</td>
            </tr>

            <tr>
                  <td colspan="5" align="center" style="font-weight: bold;">MARK SHEET</td>
            </tr>

            <tr>
                  <td style="font-weight: bold;">INSTITUTE NAME</td>
                  <td colspan="4">AMBALIKA INSTITUTE OF PROFESSIONAL STUDIES LUCKNOW CODE 2713</td>
            </tr>

            <tr>
                  <td style="font-weight: bold;">BRANCH NAME</td>
                  <td colspan="4">[322][CIVIL ENGINEERING] 03 SEMESTER</td>
            </tr>

            <tr>
                  <td style="font-weight: bold;">STUDENT NAME</td>
                  <td colspan="4"><?php echo $row[name];?></td>
            </tr>

            <tr>
                  <td style="font-weight: bold;">ROLL NUMBER</td>
                  <td colspan="4"><?php echo $row[roll];?></td>
            </tr><br>

            <tr>
                  <td style="height: 60px; font-weight: bold; text-align: center; " rowspan="1">PAPER CODE</td>
                  <td style="height: 60px; font-weight: bold; text-align: center " rowspan="1">PAPER NAME</td>
                  <td style="height: 40px; font-weight: bold; " colspan="3" align="center">MARKS</td>
                  
            </tr>


             <tr>
              <td colspan="2"></td>
                  <td style="height: 40px; font-weight: bold; ">1st Sessional</td>
                  <td style="height: 40px; font-weight: bold; ">2nd Sessional</td>
                  <td colspan="" style="height: 40px; font-weight: bold; ">3rd Sessional</td>
            </tr>

            <tr>
                  <td>322501</td>
                  <td>HYDRAULICS AND HYDRAULIC MACHINES</td>
                  <td>20 / <?php echo $row[hhm_first];?></td>
                  <td>20 / <?php echo $row[hhm_second];?></td>
                  <td>50 / <?php echo $row[hhm_third];?></td>
            </tr>

            <tr>
                  <td>322502</td>
                  <td>CONCRETE TECHNOLOGY </td>
                  <td>20 / <?php echo $row[ct_first];?></td>
                  <td>20 / <?php echo $row[ct_second];?></td>
                  <td>50 / <?php echo $row[ct_third];?></td>
            </tr>
           

            <tr>
                  <td>322503</td>
                  <td>ENVIRONMENTAL STUDIES </td>
                  <td>20 / <?php echo $row[evs_first];?></td>
                  <td>20 / <?php echo $row[evs_second];?></td>
                  <td>50 / <?php echo $row[evs_third];?></td>
            </tr>

            <tr>
                  <td>322504</td>
                  <td>STRUCTURAL MECHANICS </td>
                  <td>20 / <?php echo $row[sm_first];?></td>
                  <td>20 / <?php echo $row[sm_second];?></td>
                  <td>50 / <?php echo $row[sm_third];?></td>
            </tr>

             <tr>
                  <td>322505</td>
                  <td>BUILDING CONSTRUCTION </td>
                  <td>20 / <?php echo $row[bc_first];?></td>
                  <td>20 / <?php echo $row[bc_second];?></td>
                  <td>50 / <?php echo $row[bc_third];?></td>
            </tr>

            <tr>
                  <td>322506</td>
                  <td>BUILDING DRAWING </td>
                  <td>20 / <?php echo $row[bd_first];?></td>
                  <td>20 / <?php echo $row[bd_second];?></td>
                  <td>50 / <?php echo $row[bd_third];?></td>
            </tr>

              
            <tr>
             
                  <td align="center" style="height: 40px; font-weight: bold; "><?php echo $row[per];?> % </td>
                  <td align="center" style="height: 40px; font-weight: bold; ">540 / <?php echo $row[total_sessional];?></td>
                  
                  <td style="height: 40px; font-weight: bold;">120 / <?php echo $row[first_sessional];?></td>
                  <td style="height: 40px; font-weight: bold;">120 / <?php echo $row[second_sessional];?></td>
                  <td style="height: 40px; font-weight: bold;">300 / <?php echo $row[third_sessional];?></td>
            </tr>

            <tr>
                  <td colspan="7" style="border:none; font-size: 11px; text-align: center; background-color: grey; color: black; font-weight: bold;"><bold>DISCLAIMER :</bold> BOARD OF TECHNICAL EDUCATION UTTAR PRADESH LUCKNOW IS NOT RESPONSIBLE FOR ANY INADVERTENT ERROR THAT MAY HAVE CREPT IN THE RESULTS BEING <br>PUBLISHED HERE ON THIS WEBSITE. THE RESULTS PUBLISHED HERE ARE FOR IMMEDIATE INFORMATION TO THE EXAMINEES ONLY AND MAY NOT BE<br> CONSIDERED AS FINAL RESULT. STUDENT SHOULD CONTACT THEIR RESPECTIVE INSTITUTE FOR THE FINAL RESULTS.</td>
            </tr>



     
            <?php 
      }
      ?>
      </table>
</form>
</body>
</html>