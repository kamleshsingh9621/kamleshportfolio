<!DOCTYPE html>
<html>
<head>
	<title>ce link</title>
	<link rel="stylesheet" type="text/css" href="css/link.css">
</head>
<body>
	<div class="link">
		<div class="common">
		<div class="branch">
			<h3>FIRST SEMESTER</h3>
		<div class="subject_name">
			1.1<a href="diploma\common\physic.pdf" class="subject_content">Communication Skills-</a><br>
			1.2<a href="diploma\common\physic.pdf" class="subject_content">Applied Mathematics-I </a><br>
			1.3<a href="diploma\common\physic.pdf" class="subject_content">Applied Physics-I </a><br>
			1.4<a href="diploma\common\physic.pdf" class="subject_content">Applied Chemistry</a><br>
			1.5<a href="diploma\common\physic.pdf" class="subject_content">Engineering Drawing-I </a><br>
			1.6<a href="diploma\common\physic.pdf" class="subject_content">Construction Materials</a>
		</div>	
		</div>

		<div class="branch">
			<h3>SECOND SEMESTER</h3>
		<div class="subject_name">
			2.1<a href="diploma\common\physic.pdf" class="subject_content">Applied Mathematics-II </a><br>
			2.2<a href="diploma\common\physic.pdf" class="subject_content">Computer Aided Drawing </a><br>
			2.3<a href="diploma\common\physic.pdf" class="subject_content">Applied Mechanics </a><br>
			2.4<a href="diploma\common\physic.pdf" class="subject_content">Basics of Mechanical and Electrical Engg. </a><br>
			2.5<a href="diploma\common\physic.pdf" class="subject_content">Basics of Information Technology </a>
		</div>
			
		</div>
	</div>
	<div class="common">

		<div class="branch">
			<h3>THIRD SEMESTER</h3>
		<div class="subject_name">
			3.1<a href="diploma\common\physic.pdf" class="subject_content">Hydraulics and Hydraulic Machines </a><br>
			3.2<a href="diploma\common\physic.pdf" class="subject_content">Concrete Technology </a><br>
			3.3<a href="diploma\common\physic.pdf" class="subject_content">Environmental Studies </a><br>
			3.4<a href="diploma\common\physic.pdf" class="subject_content">Structural Mechanics </a><br>
			3.5<a href="diploma\common\physic.pdf" class="subject_content">Building Construction </a><br>
			3.6<a href="diploma\common\physic.pdf" class="subject_content">Building Drawings </a>
		</div>
		</div>

		<div class="branch">
			<h3>FOURTH SEMESTER</h3>
		<div class="subject_name">
			4.1<a href="diploma\common\physic.pdf" class="subject_content">Communication Skill-II</a><br>
			4.2<a href="diploma\common\physic.pdf" class="subject_content">Highway Engineering</a><br>
			4.3<a href="diploma\common\physic.pdf" class="subject_content">Irrigation Engineering </a><br>
			4.4<a href="diploma\common\physic.pdf" class="subject_content">Surveying - I </a><br>
			4.5<a href="diploma\common\physic.pdf" class="subject_content">Reinforced Cement Concrete Structures (RCC Structures)</a><br>
			4.6<a href="diploma\common\physic.pdf" class="subject_content">Energy Conservation</a><br>
			4.7<a href="diploma\common\physic.pdf" class="subject_content">RCC Drawing</a>	
		</div>
		</div>
	</div>
	<div class="common">

		<div class="branch">
			<h3>FIFTH SEMESTER</h3>
		<div class="subject_name">
			5.1<a href="diploma\common\physic.pdf" class="subject_content">Water and Waste Water Engineering</a><br>
			5.2<a href="diploma\common\physic.pdf" class="subject_content">Railways, Bridges and Tunnels</a><br>
			5.3<a href="diploma\common\physic.pdf" class="subject_content">Earthquake Engineering</a><br>
			5.4<a href="diploma\common\physic.pdf" class="subject_content">Soil Mechanics and Foundation Engineering </a><br>
			5.5<a href="diploma\common\physic.pdf" class="subject_content">Surveying-II </a><br>
			5.6<a href="diploma\common\physic.pdf" class="subject_content">Waste Water and Irrigation Engineering Drawing</a>
		</div>
		</div>

		<div class="branch">
			<h3>SIXTH SEMESTER</h3>
		<div class="subject_name">
			6.1<a href="diploma\common\physic.pdf" class="subject_content">Quantity Surveying and Valuation </a><br>
			6.2<a href="diploma\common\physic.pdf" class="subject_content">Construction Management, Accounts and Entrepreneurship Development </a><br>
			6.3<a href="diploma\common\physic.pdf" class="subject_content">Design of Steel Structure</a><br>
			6.4<a href="diploma\common\physic.pdf" class="subject_content">Steel Structure Drawing </a><br>
			6.5<a href="diploma\common\physic.pdf" class="subject_content">Software Application in Civil Engineering </a>
		</div>
			
		</div>
	</div>

	</div>

</body>
</html>