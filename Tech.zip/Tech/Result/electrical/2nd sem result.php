<?php
mysql_connect("localhost","root","");
mysql_select_db(webs);
if(isset($_POST['submit']))
      $roll=$_POST['roll'];
if(mysql_query($result))


?>
<html>
<body>

<input type="submit" name="submit" value="PRINT THIS PAGE" onclick="window.print()" style="margin:20px 0px 0px 530px; ">

 <?php
    mysql_connect("localhost","root","");
    mysql_select_db("webs");
    $result=mysql_query("select * from eesecond where roll=$roll;");
    ?>
    
<form method="post">
      <table border="1" height="700px"; align="center";>
          
             <?php
while($row=mysql_fetch_array($result))
        {
            ?>
                        
            



            <tr>
                  <td style="border:none;"><img src="logo.png" style="height:120px; width: 130px;"></td>
                  <td colspan="4" align="center" style="height: 60px; font-size: 25px; text-align: center; border:none; font-weight: bold;">AMBALIKA INSTITUTE OF PROFESSIONAL STUDIES  LUCKNOW<br>UTTAR PRADESH</td>
            
            </tr>

            <tr>
                  <td colspan="5" align="center" style="font-weight: bold;">SECOND SEMESTER SESSIONAL RESULT JULY-2021</td>
            </tr>

            <tr>
                  <td colspan="5" align="center" style="font-weight: bold;">MARK SHEET</td>
            </tr>

            <tr>
                  <td style="font-weight: bold;">INSTITUTE NAME</td>
                  <td colspan="4">AMBALIKA INSTITUTE OF PROFESSIONAL STUDIES LUCKNOW CODE 2713</td>
            </tr>

            <tr>
                  <td style="font-weight: bold;">BRANCH NAME</td>
                  <td colspan="4">[328][ELECTRICAL ENGINEERING] 02 SEMESTER</td>
            </tr>

            <tr>
                  <td style="font-weight: bold;">STUDENT NAME</td>
                  <td colspan="4"><?php echo $row[name];?></td>
            </tr>

            <tr>
                  <td style="font-weight: bold;">ROLL NUMBER</td>
                  <td colspan="4"><?php echo $row[roll];?></td>
            </tr><br>

            <tr>
                  <td style="height: 60px; font-weight: bold; text-align: center; " rowspan="1">PAPER CODE</td>
                  <td style="height: 60px; font-weight: bold; text-align: center " rowspan="1">PAPER NAME</td>
                  <td style="height: 40px; font-weight: bold; " colspan="3" align="center">MARKS</td>
                  
            </tr>


             <tr>
              <td colspan="2"></td>
                  <td style="height: 40px; font-weight: bold; ">1st Sessional</td>
                  <td style="height: 40px; font-weight: bold; ">2nd Sessional</td>
                  <td colspan="" style="height: 40px; font-weight: bold; ">3rd Sessional</td>
            </tr>

            

            <tr>
                  <td>328401</td>
                  <td>APPLIED MATHEMATICS -2</td>
                  <td>20 / <?php echo $row[math_first];?></td>
                  <td>20 / <?php echo $row[math_second];?></td>
                  <td>50 / <?php echo $row[math_third];?></td>
            </tr>

            <tr>
                  <td>328402</td>
                  <td>APPLIED PHYSICS -2</td>
                  <td>20 / <?php echo $row[physics_first];?></td>
                  <td>20 / <?php echo $row[physics_second];?></td>
                  <td>50 / <?php echo $row[physics_third];?></td>
            </tr>

            <tr>
                  <td>328403</td>
                  <td>BASIC ELECTRICAL ENGINEERING</td>
                  <td>20 / <?php echo $row[ee_first];?></td>
                  <td>20 / <?php echo $row[ee_second];?></td>
                  <td>50 / <?php echo $row[ee_third];?></td>
            </tr>

            <tr>
                  <td>328404</td>
                  <td>BASIC OF MECHANICAL & CIVIL ENGINEERING</td>
                  <td>20 / <?php echo $row[mce_first];?></td>
                  <td>20 / <?php echo $row[mce_second];?></td>
                  <td>50 / <?php echo $row[mce_third];?></td>
            </tr>

             <tr>
                  <td>328405</td>
                  <td>ANALOG ELECTRONICS</td>
                  <td>20 / <?php echo $row[ae_first];?></td>
                  <td>20 / <?php echo $row[ae_second];?></td>
                  <td>50 / <?php echo $row[ae_third];?></td>
            </tr>

             
            <tr>
             
                  <td align="center" style="height: 40px; font-weight: bold; "><?php echo $row[per];?> % </td>
                  <td align="center" style="height: 40px; font-weight: bold; ">450 / <?php echo $row[total_sessional];?></td>
                  
                  <td style="height: 40px; font-weight: bold;">100 / <?php echo $row[first_sessional];?></td>
                  <td style="height: 40px; font-weight: bold;">100 / <?php echo $row[second_sessional];?></td>
                  <td style="height: 40px; font-weight: bold;">250 / <?php echo $row[third_sessional];?></td>
            </tr>

            <tr>
                  <td colspan="7" style="border:none; font-size: 11px; text-align: center; background-color: grey; color: black; font-weight: bold;"><bold>DISCLAIMER :</bold> BOARD OF TECHNICAL EDUCATION UTTAR PRADESH LUCKNOW IS NOT RESPONSIBLE FOR ANY INADVERTENT ERROR THAT MAY HAVE CREPT IN THE RESULTS BEING <br>PUBLISHED HERE ON THIS WEBSITE. THE RESULTS PUBLISHED HERE ARE FOR IMMEDIATE INFORMATION TO THE EXAMINEES ONLY AND MAY NOT BE<br> CONSIDERED AS FINAL RESULT. STUDENT SHOULD CONTACT THEIR RESPECTIVE INSTITUTE FOR THE FINAL RESULTS.</td>
            </tr>



     
            <?php 
      }
      ?>
      </table>
</form>
</body>
</html>