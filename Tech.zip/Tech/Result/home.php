<!DOCTYPE html>
<html>
<head>
	<title>home</title>
	<style type="text/css">
		.result_home{
			width: 100%;
			height: auto;

		}
		.home_image{
			width: 100%;
			height: 500px;
		}
	</style>
</head>
<body>
	<div class="result_home">
		<img src="images/slider4.jpg" class="home_image">
		
	</div>

</body>
</html>