<?php
include "header.php";
include "home.php";
?>

<div id="wrapper">
    <?php 
	   if (isset($_REQUEST['pageid']) )
		{
			include_once($_REQUEST['pageid']. ".php"); 
		}
		else 
		{
			include_once("index.php");
		} 
		?>
</div>
<br>
<?php
include "footer.php";
?>
