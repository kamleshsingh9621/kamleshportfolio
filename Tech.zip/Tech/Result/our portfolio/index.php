<?php
mysql_connect("localhost","root","");
mysql_select_db(our_portfolio);
if(isset($_POST['submit']))
{
    $name=$_POST['name'];
    $email=$_POST['email'];
    $mobile=$_POST['phone'];
    $subject=$_POST['subject'];
    $message=$_POST['message'];
    $result="insert into contact(Name,Email,Mobile,Subject,Message)values('$name','$email','$mobile','$subject','$message')";
    if(mysql_query($result))
    {
    echo '<script type="text/javascript">window.alert("Data has been submitted to  ' .$email  .'");</script>';

    }
    else
    {
        echo "data not stored";
    }


}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <style type="text/css">
    	@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap');

*{
    padding: 0;
    margin: 0;
    box-sizing: border-box;
}

body{
    font-family: 'Poppins', sans-serif;
}

ul{
    list-style: none;
}

a{
    text-decoration: none;
}
a:hover{
     text-decoration: none;
     font-weight: bold;
}
header{
    position: sticky;
    top: 0px;
    background-color: white;
    width: 100%;
    z-index: 1000;
}

section{
    position: relative;
    width: 100%;
    background-color: blue;
}

.overlay{
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background-color: rgb(56, 165, 238, 0.5);
}

.container{
    max-width: 65rem;
    padding: 0 2rem;
    margin: 0 auto;
    display: flex;
    position: relative;
}

.logo-container{
    flex: 1;
    display: flex;
    align-items: center;
    margin:0px 0px 0px -150px;

}

.nav-btn{
    flex: 3;
    display: flex;
}

.nav-links{
    flex: 2;
}

.log-sign{
    display: flex;
    justify-content: center;
    align-items: center;
    flex: 1;
}

.logo{
    color: blue;
    font-size: 1.1rem;
    font-weight: 600;
    letter-spacing: 2px;
    text-transform: uppercase;
    line-height: 2rem;
    text-align: center;
    align-items: center;
    margin:0px 0px 0px 130px;
}


.btn{
    display: inline-block;
    padding: .5rem 1.3rem;
    font-size: .8rem;
    border: 2px solid #7da7d1;
    border-radius: 2rem;
    line-height: 1;
    margin: 0 .2rem;
    transition: .3s;
    text-transform: uppercase;
}

.btn.solid, .btn.transparent:hover{
    background-color: #254b70;
    color: white;
}

.btn.transparent, .btn.solid:hover{
    background-color: transparent;
    color: black;
}

.nav-links > ul{
    display: flex;
    justify-content: center;
    align-items: center;
}

.nav-link{
    position: relative;
}

.nav-link > a{
    line-height: 3rem;
    color: black;
    padding: 0 .8rem;
    letter-spacing: 1px;
    font-size: .95rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    transition: .5s;
}

.nav-link > a > i{
    margin-left: .2rem;
}

.nav-link:hover > a{
    transform: scale(1.1);
}

.dropdown{
    position: absolute;
    top: 100%;
    left: 0;
    width: 10rem;
    transform: translateY(10px);
    opacity: 0;
    pointer-events: none;
    transition: .5s;
}

.dropdown ul{
    position: relative;
}

.dropdown-link > a{
    display: flex;
    background-color: #fff;
    color: black;
    padding: .5rem 1rem;
    font-size: .9rem;
    align-items: center;
    justify-content: space-between;
    transition: .3s;
}

.dropdown-link:hover > a{
    background-color: #3498db;
    color: #fff;
}

.dropdown-link:not(:nth-last-child(2)){
    border-bottom: 1px solid #efefef;
}

.dropdown-link i{
    transform: rotate(-90deg);
}

.arrow{
    position: absolute;
    width: 11px;
    height: 11px;
    top: -5.5px;
    left: 32px;
    background-color: #fff;
    transform: rotate(45deg);
    cursor: pointer;
    transition: .3s;
    z-index: -1;
}

.dropdown-link:first-child:hover ~ .arrow{
    background-color: #3498db;
}

.dropdown-link{
    position: relative;
}

.dropdown.second{
    top: 0;
    left: 100%;
    padding-left: .8rem;
    cursor: pointer;
    transform: translateX(10px);
}

.dropdown.second .arrow{
    top: 10px;
    left: -5.5px;
}

.nav-link:hover > .dropdown,
.dropdown-link:hover > .dropdown{
    transform: translate(0, 0);
    opacity: 1;
    pointer-events: auto;
}

.hamburger-menu-container{
    flex: 1;
    display: none;
    align-items: center;
    justify-content: flex-end;
}

.hamburger-menu{
    width: 2.5rem;
    height: 2.5rem;
    display: flex;
    align-items: center;
    justify-content: flex-end;
}

.hamburger-menu div{
    width: 1.6rem;
    height: 3px;
    border-radius: 3px;
    background-color: black;
    position: relative;
    z-index: 1001;
    transition: .5s;
}

.hamburger-menu div:before,
.hamburger-menu div:after{
    content: '';
    position: absolute;
    width: inherit;
    height: inherit;
    background-color: black;
    border-radius: 3px;
    transition: .5s;
}

.hamburger-menu div:before{
    transform: translateY(-7px);
}

.hamburger-menu div:after{
    transform: translateY(7px);
}

#check{
    position: absolute;
    top: 50%;
    right: 1.5rem;
    transform: translateY(-50%);
    width: 2.5rem;
    height: 2.5rem;
    z-index: 90000;
    cursor: pointer;
    opacity: 0;
    display: none;
}

#check:checked ~ .hamburger-menu-container .hamburger-menu div{
    background-color: transparent;
}

#check:checked ~ .hamburger-menu-container .hamburger-menu div:before{
    transform: translateY(0) rotate(-45deg);
}

#check:checked ~ .hamburger-menu-container .hamburger-menu div:after{
    transform: translateY(0) rotate(45deg);
}

@keyframes animation{
    from{
        opacity: 0;
        transform: translateY(15px);
    }
    to{
        opacity: 1;
        transform: translateY(0px);
    }
}

@media (max-width: 920px){
    .hamburger-menu-container{
        display: flex;
    }

    #check{
        display: block;
    }

    .nav-btn{
        position: fixed;
        height: calc(100vh - 3rem);
        top: 3rem;
        left: 0;
        width: 100%;
        background-color: #69bde7;
        flex-direction: column;
        align-items: center;
        justify-content: space-between;
        overflow-x: hidden;
        overflow-y: auto;
        transform: translateX(100%);
        transition: .65s;
    }

    #check:checked ~ .nav-btn{
        transform: translateX(0);
    }

    #check:checked ~ .nav-btn .nav-link,
    #check:checked ~ .nav-btn .log-sign{
        animation: animation .5s ease forwards var(--i);
    }

    .nav-links{
        flex: initial;
        width: 100%;
    }

    .nav-links > ul{
        flex-direction: column;
    }

    .nav-link{
        width: 100%;
        opacity: 0;
        transform: translateY(15px);
    }

    .nav-link > a{
        line-height: 1;
        padding: 1.6rem 2rem;
    }

    .nav-link:hover > a{
        transform: scale(1);
        background-color: #50a9d6;
    }

    .dropdown, .dropdown.second{
        position: initial;
        top: initial;
        left: initial;
        transform: initial;
        opacity: 1;
        pointer-events: auto;
        width: 100%;
        padding: 0;
        background-color: #3183ac;
        display: none;
    }
    
    .nav-link:hover > .dropdown,
    .dropdown-link:hover > .dropdown{
        display: block;
    }

    .nav-link:hover > a > i,
    .dropdown-link:hover > a > i{
        transform: rotate(360deg);
    }

    .dropdown-link > a{
        background-color: transparent;
        color: #fff;
        padding: 1.2rem 2rem;
        line-height: 1;
    }

   

    .dropdown-link:not(:nth-last-child(2)){
        border-bottom: none;
    }

    .arrow{
        z-index: 1;
        background-color: #69bde7;
        left: 10%;
        transform: scale(1.1) rotate(45deg);
        transition: .5s;
    }

    .nav-link:hover .arrow{
        background-color: #50a9d6;
    }

    .dropdown .dropdown .arrow{
        display: none;
    }

    .dropdown-link:hover > a{
        background-color: #3a91bd;
    }

    .dropdown-link:first-child:hover ~ .arrow{
        background-color: #50a9d6;
    }

    .nav-link > a > i{
        font-size: 1.1rem;
        transform: rotate(-90deg);
        transition: .7s;
    }

    .dropdown i{
        font-size: 1rem;
        transition: .7s;
    }

    .log-sign{
        flex: initial;
        width: 100%;
        padding: 1.5rem 1.9rem;
        justify-content: flex-start;
        opacity: 0;
        transform: translateY(15px);
    }
}

        /*ABOUT SECTONS START*/


.about{
    display: flex;
    height: 100vh;
    background-color: none;
}
.my-photo{
    width: 50%;
    height: 700px;
}
.my-photo img{
    width: 100%;
    height: 700px;
}
.my-intro{
    justify-content: center;
    text-align: left;
    background-color: none;
    width: 50%;
}
.my-intro h6{
    margin:8% 0% 0% 5%;
    font-weight: bolder;
}
.my-intro h1{
    margin:3% 0% 0% 8%;
}
.my-intro P{
     margin:3% 0% 0% 8%;

}
.basic-detail{
     display: flex;
    background-color: none;
    margin:3% 0% 0% 5%;

}
.basic-detail .ques{
    margin:0% 0% 0% 0%;
    background-color: none;
    width: 40%;
 
}
.basic-detail .ques h6{
    margin:10% 0% 0% 12%;

}
.basic-detail .ans{
    margin:0% 0% 0% 0%;
    width: 100%;
 
}
.basic-detail .ques p{
    margin:5% 0% 0% 0%;

}
.download-resume{
    background-color: #101211;
    width: 30%;
    height:7%;
    text-align: center;
    align-items: center;
    margin:6% 0% 0% 22%;
    border-radius: 10px;
    padding-top: 5px;
    padding-right: 5px;
    box-shadow: 0px 0px 0px 3px grey;

}
.download-resume p{
    color: white;

}
.download-resume:active{
    box-shadow: 0px 0px 0px 0px white;

}

    /*ABOUT SECTIONS END*/



    /*SKILLS SECTIONS START*/
.my-skills{
    font-size: 230%;
    margin-left:45%; 
    font-weight: bold;


    }

.skills{
    position: relative;
    justify-content: center;
    text-align: center;
    align-items: center;
    background-color: red;
    width: 100%;
    height: 100vh;
    margin:2% 0% 0% 0%;
    box-shadow: 0px 0px 25px red;
}

.box{
    position: relative;
    float: left;
    width: 30%;
    height: 45%;
    background-color: none;
    margin:2% 0% 0% 2%;
    border-radius: 10px;
    box-shadow: 0px 35px 25px black;

}
.box:hover{
    background-color:red;
    box-shadow:0px 5px 15px white; 
    color: white;
}
.box h4{
    margin:7% 0% 0% 0%;
    font-weight: bold;
}
.circle{
    width: 40%;
    height: 50%;
    background-color: none;
    border:5px solid black;
    border-radius: 50%;
    margin:5% 0% 0% 30%;
    text-align: center;
    align-items: center;
    justify-content: center;

}
.circle:hover{
    color: black;
    border: 5px solid white;
}
.circle h1{
    padding-top: 27%;

}
.range{
    margin:4% 0% 0% 0%;
    width:70%; 
}

        /*SKILLS SECTIONS END*/



        /*SERVICES SECTIONS START*/


.services{
    position: relative;
    width: 100%;
    height: 100vh;
    background-color: none;
    justify-content: center;
    display: inline-block;
    margin: 5% 0% 0% 0%;

}
.service-box{
    float: left;
    width: 20%;
    height: 40%;
    background-color: none;
    margin:2% 0% 0% 4%;
    border-radius: 0px;
    box-shadow: 0px 35px 25px black;
} 
.service-box:hover{
    box-shadow: 0px 0px 15px red;
    background-color: black;
    color: white;

} 
.service-img{
    width: 30%;
    height: 30%;
    margin:10% 0% 0% 33%;
} 

.service-name{
    text-align: center;
    margin: 3% 0% 0% 0%;
    font-weight: bold;
}
.string{
    text-align: center;
}
.project{
    width: 100%;
    height: auto;
    background-color: grey;
}
.heading{
    margin:4% 0% 0% 3%;
    font-size: 40px;
    font-weight: bold;
}
.project-content{
    color: white;
    margin:1% 0% 0% 3%;
}
.contactme{
    padding: 1%;
    width: 12%;
    height: 50px;
    background-color: white;
    text-align:center;
    margin:2% 0% 0% 5%;
    border-radius: 8px;

}
.contactme a{
    color: black;
    }
    .contact{
        width: 100%;
        height: 100%;
        justify-content: center;
        float: left;
    }
    .map{
        float: left;

    }
    .contact{
        background-color: none;
    }
    form{
        margin:0% 0% 0% 0%;
    }
    .name{
        width: 190%;
        height: 50px;
        margin:10% 0% 0% 5%;
    }
    .message{
        width: 190%;
        height: 120px;
        margin:5% 0% 0% 5%;
    }
    .contact_button{
        background-color: black;
        color: white;
        width: 50%;
        height: 40px;
        margin:10% 0% 0% 55%;
    }
    .contact-submit{
        width: 100%;
        height: 40px;
        background-color: black;
        color: white;
    }


footer{
    position: all;
    margin:50% 0% 0% 0%;
    bottom: 0;
    left: 0;
    right: 0;
    background: #111;
    height: auto;
    width: 100vw;

    padding-top: 40px;
    color: #fff;
}
.footer-content{
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    text-align: center;
}
.footer-content h3{
    font-size: 2.1rem;
    font-weight: 500;
    text-transform: capitalize;
    line-height: 3rem;
}
.footer-content p{
    max-width: 500px;
    margin: 10px auto;
    line-height: 28px;
    font-size: 14px;
    color: #cacdd2;
}
.socials{
    list-style: none;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 1rem 0 3rem 0;
}
.socials li{
    margin: 0 10px;
}
.socials a{
    text-decoration: none;
    color: #fff;
    border: 1.1px solid white;
    padding: 5px;

    border-radius: 50%;

}
.socials a i{
    font-size: 1.1rem;
    width: 20px;


    transition: color .4s ease;

}
.socials a:hover i{
    color: aqua;
}

.footer-bottom{
    background: #000;
    width: 100vw;
    padding: 20px;
padding-bottom: 40px;
    text-align: center;
}
.footer-bottom p{
float: left;
    font-size: 14px;
    word-spacing: 2px;
    text-transform: capitalize;
}
.footer-bottom p a{
  color:#44bae8;
  font-size: 16px;
  text-decoration: none;
}
.footer-bottom span{
    text-transform: uppercase;
    opacity: .4;
    font-weight: 200;
}
.footer-menu{
  float: right;

}
.footer-menu ul{
  display: flex;
}
.footer-menu ul li{
padding-right: 10px;
display: block;
}
.footer-menu ul li a{
  color: #cfd2d6;
  text-decoration: none;
}
.footer-menu ul li a:hover{
  color: #27bcda;
}

@media (max-width:500px) {
.footer-menu ul{
  display: flex;
  margin-top: 10px;
  margin-bottom: 20px;
}
}


        /*SERVICES SECTIONS END*/     
    </style>
    <title>our portfolio</title>
</head>

<body>
    <header>
        <div class="container">
            <input type="checkbox" name="" id="check">
            
         <a href="index.php"><div class="logo-container">
               <a href=""> <h3 class="logo">Logo</h3></a>
            </div>
        

            <div class="nav-btn">
                <div class="nav-links">
                    <ul>
                        <li class="nav-link" style="--i: .2s">
                            <a href="#home">Home</a>
                        </li>
                        <li class="nav-link" style="--i: .4s">
                            <a href="#about">About</a>
                        </li>
                        <li class="nav-link" style="--i: .6s">
                            <a href="#skill">Skills</a>
                        </li>
                        <li class="nav-link" style="--i: .8s">
                            <a href="#blog">Blogs</a>
                        </li>
                        <li class="nav-link" style="--i: 1.0s">
                            <a href="#service">Services</a>
                        </li>
                        
                        <li class="nav-link" style="--i: 1.2s">
                            <a href="#contact">Contact Us</a>
                        </li>
                        
                    </ul>
                </div>

               
            </div>

            <div class="hamburger-menu-container">
                <div class="hamburger-menu">
                    <div></div>
                </div>
            </div>
        </div>
    </header>
    <a name="home"></a>
    <main>
        <section>
            <div class="overlay"></div>
        </section>
    </main>

    <div class="bd-example">
  <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="img/slider4.jpg" class="d-block w-100" alt="..." style="height:520px;">
        <div class="carousel-caption d-none d-md-block">
          <h1 style="color: black;">First slide label</h1>
          <p style="color: black;">Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="img/slider2.jpg" class="d-block w-100" alt="..."  style="height:520px;">
        <div class="carousel-caption d-none d-md-block">
          <h1 style="color: black;">Second slide label</h1>
          <p style="color: black;">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="img/slider3.jpg" class="d-block w-100" alt="..." style="height:520px;">
        <div class="carousel-caption d-none d-md-block">
          <h1 style="color: black;">Third slide label</h1>
          <p style="color: black;">Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
<br>
<a href="#home">
    <i class='fas fa-arrow-alt-circle-up' style='font-size:48px;color:red; position:fixed; margin:-100px 0px 0px 1150px;'></i>
    </a>

        <!-- ABOUT SECTION START --> 

<a name="about"></a><br><br><br>
<div class="about">
    <div class="my-photo">
        <img src="img/kamlesh.png">
    </div>
    <div class="my-intro">
        <h6>MY INTRO</h6>
        <h1>About Me</h1>
        <P>A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</P>
        <div class="basic-detail">
            <div class="ques">
                <h6>Name : </h6>
                <h6>Email : </h6>
                <h6>Phone : </h6>
                <h6>Address : </h6>
                <h6>Date of birth : </h6>
                <h6>Zip code : </h6>
            </div>
            <div class="ans">
                <p>Kamlesh Singh</p>
                <p>kamleshsingh752581@gmail.com</p>
                <p>7525818779</p>
                <p>Padrauna, Kushinagar, UP</p>
                <p>01/01/2000</p>
                <p>274304</p>   
            </div> 
        </div> 
        <a href="kamlesh resume.docx">
            <div class="download-resume">
                <p>DOWNLOAD RESUME</p>
            </div>
        </a>

    </div>
</div>
<br>
    

    <!--  ABOUT SECTION END -->


    <!-- SKILLS SECTIONS START -->
<a name="skill"></a><br><br><br><br><br>
    <p class="my-skills">My Skills</p>
    <div class="skills">
        <div class="box">
            <h4>HTML</h4>
            <div class="circle">
                <h1>95%</h1>    
            </div>
            <input type="range" name="" class="range" value="95">

        </div>
        <div class="box">
            <h4>CSS</h4>
            <div class="circle">
                <h1>80%</h1>    
            </div>
            <input type="range" name="" class="range" value="80">
        </div>
        <div class="box">
            <h4>JAVASCRIPT</h4>
            <div class="circle">
                <h1>65%</h1>    
            </div>
            <input type="range" name="" class="range" value="65">
        </div>
        <br>
        <div class="box">
            <h4>PHP</h4>
            <div class="circle">
                <h1>85%</h1>    
            </div>
            <input type="range" name="" class="range" value="80">
        </div>
        <div class="box">
            <h4>MYSQL</h4>
            <div class="circle">
                <h1>70%</h1>    
            </div>
            <input type="range" name="" class="range" value="70">
        </div>
        <div class="box">
            <h4>BOOTSTRAP</h4>
            <div class="circle">
                <h1>90%</h1>    
            </div>
            <input type="range" name="" class="range" value="90">
        </div>
        
    </div>
    <br>
    <!-- SKILLS SECTION END -->


   <!--  SERVICES SECTIONS START -->
   <a name="service"></a><br><br><br>
   <div class="services">
        <p class="my-skills">Our Services</p>


    <div class="service-box">
        <img src="img/pc.jpg" class="service-img">
        <h5 class="service-name">Web Development</h5><br>
        <p class="string">You can learn web developement from this website.</p>
        
        
    </div>
    <div class="service-box">
        <img src="img/pc1.jpg" class="service-img">
        <h5 class="service-name">Frontend Development</h5><br>
        <p class="string">You can learn web design from this website.</p>
        
    </div>
    <div class="service-box">
        <img src="img/pc7.jpg" class="service-img">
        <h5 class="service-name">Backend Development</h5><br>
        <p class="string">You can learn web design from this website.</p>
        
    </div>
    <div class="service-box">
        <img src="img/pc3.jpg" class="service-img">
        <h5 class="service-name">Graphic Design</h5><br>
        <p class="string">You can learn web design from this website.</p>
        
    </div>
    <div class="service-box">
        <img src="img/pc4.jpg" class="service-img">
        <h5 class="service-name">PHP Development</h5><br>
        <p class="string">You can learn web design from this website.</p>
        
    </div>
    <div class="service-box">
        <img src="img/pc5.jpg" class="service-img">
        <h5 class="service-name">Java Development</h5><br>
        <p class="string">You can learn web design from this website.</p>
        
    </div>
    <div class="service-box">
        <img src="img/pc6.jpg" class="service-img">
        <h5 class="service-name">Photography</h5><br>
        <p class="string">You can learn web design from this website.</p>
        
    </div>
    <div class="service-box">
        <img src="img/pc8.jpg" class="service-img">
        <h5 class="service-name">Full Stack Development</h5><br>
        <p class="string">You can learn web design from this website.</p>
        
    </div>
       
   </div><br>


   <div class="project">
    <p class="heading">Have a project on your mind ?</p>
    <p class="project-content">A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country,<br> in which roasted parts of sentences fly.</p>
    <div class="contactme">
        <a href="#contact">Contact me</a>
    </div>
    <br><br>
       
   </div>
   <br><br><br><br>

   <!-- SERVICES SECTIONS END -->





    <!-- CONTACT SECTION START --> 
<a name="contact"></a><br><br><br><br>

    <div class="contact">
        <p class="my-skills">Contact Us</p><br><br>
        <div class="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d227821.9337621567!2d80.80242503190256!3d26.848929330925085!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399bfd991f32b16b%3A0x93ccba8909978be7!2sLucknow%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1676631640114!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            
        </div>
        <div class="contact-form">
            <form method="post" autocomplete="off">
                <table>
                    <tr>
                        <td><input type="text" name="name" placeholder="Full Name *" class="name"></td>
                    </tr>
                    <tr>
                        <td><input type="email" name="email" placeholder="Email *" class="name"></td>
                    </tr>
                    <tr>
                        <td><input type="tel" name="phone" placeholder="Mobile no *" class="name"></td>
                    </tr>
                    <tr>
                        <td><input type="text" name="subject" placeholder="Subject" class="name"></td>
                    </tr>
                    <tr>
                        <td><input type="text" name="message" placeholder="Message *" class="message"></td>
                    </tr>
                    <tr>
                        <td>
                            <div class="contact_button">
                                <input type="submit" name="submit" value="submit" class="contact-submit">
                            </div>
                        </td>
                    </tr>
                </table>
            </form>
        </div>    
    </div><br><br><br><br>


    <!--  CONTACT SECTION END -->


    <!-- FOOTER START -->
<footer>
        <div class="footer-content">
            <h3>Kamlesh Developer</h3>
            <p>Raj Template is a blog website where you will find great tutorials on web design and development. Here each tutorial is beautifully described step by step with the required source code.</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="https://wa.me/qr/VND7FDZFULYKH1"><i class="fa fa-whatsapp"></i></a></li>
                <li><a href="#"><i class="fa fa-telegram"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin-square"></i></a></li>
            </ul>
        </div>
        <div class="footer-bottom">
            <p>copyright &copy; <a href="kamlesh resume.docx">Kamlesh Developer</a>  </p>
                    <div class="footer-menu">
                      <ul class="f-menu">
                        <li><a href="#home">Home</a></li>
                        <li><a href="#about">About</a></li>
                        <li><a href="#skill">Skills</a></li>
                        <li><a href="#service">Services</a></li>
                        <li><a href="#contact">Contact</a></li>
                      </ul>
                    </div>
        </div>

    </footer>
    <!-- FOOTER END -->
    

</body>

</html>
