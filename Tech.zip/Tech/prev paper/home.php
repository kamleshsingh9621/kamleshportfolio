
<!DOCTYPE html>
<html>
<head>
	<title>home</title>
	<style type="text/css">
		.home_container{
			width: 100%;
			height: auto;
		}


		.full_image{
			width: 100%;
			height: 400px;
		}
		.ambalika_image{
			width: 100%;
			height: 400px;
		}






	</style>
</head>
<body>
	<div class="home_container">
		<div class="full_image">
			<img src="images/ambalika.png" class="ambalika_image">
			
		</div><br><br>











	</div>
</body>
</html>
