<?php
error_reporting(0);
mysql_connect("localhost","root","");
mysql_select_db(webs);
if(isset($_POST['submit']))
	$roll=$_POST['roll'];
if(mysql_query($result))


?>

<!DOCTYPE html>
<html>
<head>
	<title>computer 1st sem</title>
	<!-- FOR GOGGLE FONTS -->
	    <link href="https://fonts.googleapis.com/css2?family=Fasthand&display=swap" rel="stylesheet">

	<style type="text/css">
		*{
			padding: 0;
			margin: 0;
			box-sizing: border-box;
		}
		.container1{
			width: 100%;
			height: auto;
			background: black;
			display: flex;
		}
		.container1 img{
			padding: 10px 10px;
			width: 90px;
			height: 90px;
		}
		.container1 h1{
			margin:0px 0px 0px 50px;
			padding: 35px 0px;
			font-size: 36px;
			font-family: 'Alkatra', bold;
  			background: -webkit-linear-gradient(red, green, blue, pink);
  			-webkit-background-clip: text;
  			-webkit-text-fill-color: transparent;
  			font-weight: bold;
  			 transform: scaleY(1.4);
		}
		h2{
			margin:0px 0px 0px 200px;
			font-size: 30px;

		}
		.form{
			width: 100%;
			height: auto;
			background: none;
			text-align: center;
			align-items: center;
			margin:20px 0px 0px 0px;
		}
		.form-box{
			width: 100%;
			height: auto;
			background: none;
			text-align: center;
			align-items: center;
		}
		.form-box label{
			
			font-size: 22px;
		}
		.form-box input{
			width: 250px;
			height: 45px;
			border-radius: 5px;

		}
		::-webkit-input-placeholder{
			font-size: 16px;
			font-weight: bold;
		}
		p{
			font-weight: bold;
			padding: 10px 0px;

		}

		input[type="submit"]{
			background: -webkit-linear-gradient(green, blue, red);
			width: 150px;
			color: white;
			font-size: 19px;
			border: none;
			font-weight: bold;
		}
		input[type="submit"]:hover{
			background: -webkit-linear-gradient(red, white, blue);
			color: black;
			transition: 2s;
			transition: scale(1.5);
			
		}

		
	</style>
</head>
<body>
	<div class="container1">
		<img src="logo.png">
		<h1>AIPS COLLEGE STUDENTS ALL SESSIONAL RESULTS</h1>
	</div>
		<br><br>
		<h2>
			PLEASE ENTER YOUR ROLL NUMBER & CLICK SHOW BUTTON
		</h2>
		<div class="form">
			<form method="post" action="computer/1st sem result.php">
				<div class="form-box">
					<label>ROLL NO&nbsp;:&nbsp;</label>
					<input type="text" name="roll" placeholder="Students Roll Nunber">
						<p>ROLL NUMBER:EXAMPLE-<font color="blue"> 2329363555003</font></p>
						<br><br>
						
					<input type="submit" name="submit" value="Show Result">			
				</div>	
			</form>
		</div>
		<br><br>
</body>
</html>
