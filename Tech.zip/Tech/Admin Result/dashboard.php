<?php 
include('master.php'); 
?>



<!DOCTYPE html>
<html>
<head>
  <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Dashboard</title>
</head>
<body>

</body>
</html>

		<div class="cont" style="margin-left: 230px; background: black;">
			<section class="text-gray-600 body-font">
  <div class="container px-5 py-24 mx-auto">
    
    <div class="flex flex-wrap -m-4 text-center">
      <div class="p-4 md:w-1/4 sm:w-1/2 w-full">
        <div class="border-2 border-gray-200 px-4 py-6 rounded-lg">
          <h1 class="title-font font-medium text-3xl text-blue-900"><i class="fa fa-rupee" aria-hidden="true" style="color: white;"></i></h1>
          <h2 class="title-font font-medium text-3xl text-gray-900" style="color: white;">2.7K</h2>
          <p class="leading-relaxed" style="color: white;">Deposite</p>
        </div>
      </div>
      <div class="p-4 md:w-1/4 sm:w-1/2 w-full">
        <div class="border-2 border-gray-200 px-4 py-6 rounded-lg">
          <h1 class="title-font font-medium text-3xl text-blue-900"><i class="fa fa-rupee" aria-hidden="true" style="color: blue;"></i></h1>
          <h2 class="title-font font-medium text-3xl text-gray-900" style="color: blue;">2.7K</h2>
          <p class="leading-relaxed" style="color: blue;">Withdraw</p>
        </div>
      </div>
      <div class="p-4 md:w-1/4 sm:w-1/2 w-full">
        <div class="border-2 border-gray-200 px-4 py-6 rounded-lg">
          <h1 class="title-font font-medium text-3xl text-blue-900"><i class="fa fa-users" aria-hidden="true" style="color: white;"></i></h1>
          <h2 class="title-font font-medium text-3xl text-gray-900" style="color: white;">1.3K</h2>
          <p class="leading-relaxed" style="color: white;">Total Users</p>
        </div>
      </div>
      
      
    </div>
  </div>
</section>
			
		</div>
	</div>

</body>
</html>