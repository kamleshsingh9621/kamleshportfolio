
<html>
<head>
<title>footer</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">

  
<link rel="stylesheet" type="text/css" href="css/home.css">
<style type="text/css">
  


            /*Footer */



footer{
     background-color: #000000ff;
     position: relative;
     width: 100%;
     min-height: 350px;
     padding: 3rem 1rem;
}
.container2 {
    max-width: 1140px;
    margin: 100px 0px 0px 0px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    height: 50px;


}
.row{
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.col{
    min-width: 250px;
    color:#f2f2f2f2;
    font-family: poppins;
    padding:0 2rem;
}
.col .logo{
    width: 100px;
    margin-bottom:25px;
}
.col h3{
    color:#ff014fff;
    margin-bottom: 20px;
    position: relative;
    cursor: pointer;
}
.col h3::after{
    content: '';
    height:3px;
    width:0px;
    background-color: #ff014fff;
    position: absolute;
    bottom: 0;
    left:0;
    transition: 0.3s ease;

}
.col h3:hover::after{
    width:30px
}
.col .social a i{
    color:#ff014fff;
    margin-top:2rem;
    margin-right: 5px;
    transition: 0.3s ease;
}
.col .social a i:hover{
    transform: scale(1.5);
    filter:grayscale(25);
}
.col .links a{
    display: block;
    text-decoration: none;
    color:#f2f2f2;
    margin-bottom: 5px;
    position: relative;
    transition: 0.3s ease;
}
.col .links a::before{
    content:'';
    height: 16px;
    width:3px;
    position: absolute;
    top:5px;
    left:-10px;
    background-color: #ff014fff;
    transition: 0.5s ease;
    opacity: 0;
}
.col .links a:hover::before{
    opacity: 1;
}
.col .links a:hover{
    transform: translateX(-8px);
    color:#ff014fff;
}
.col .contact-details{
    justify-content: space-between;
}
.col .contact-details i{
    margin-right:15px;
}

/********** Responsive Design ********/
@media(max-width:900px)
{
  .container2 {
    height: auto;
  }
  .row{
    flex-direction: column;
  }
  .col{
    width: 100%;
    text-align: left;
    margin-bottom: 25px;
  }
}
@media(max-width:768px)
{
  .container2 {
    height: auto;
  }
  .row{
    flex-direction: column;
  }
  .col{
    width: 100%;
    text-align: left;
    margin-bottom: 20px;
  }
}


</style>
</head>

<body>

          <!-- Footer -->


     <footer>
        <div class="container2">
            <div class="row">
                  <div class="col" id="company">
                      <img src="logo.png" alt="" class="logo">
                      <p>
                       Our Website is used for easily download to previous years question paper.
                      </p>
                      <div class="social">
                        <a href="https://www.facebook.com/groups/182047607551099/"><i class="fab fa-facebook"></i></a>&nbsp;&nbsp;&nbsp;
                        <a href="https://ig.me/j/AbYFAiUuc0qkPLaJ/"><i class="fab fa-instagram"></i></a>&nbsp;&nbsp;&nbsp;
                        <a href="https://chat.whatsapp.com/Lj9AkGbHCIe8RmA5HpCAaC"><i class="fab fa-whatsapp"></i></a>
                        
                      </div>
                  </div>


                  <div class="col" id="services">
                     <h3>Services</h3>
                     <div class="links">
                        <a href="#">Web Design</a>
                        <a href="#">Web Developement</a>
                        <a href="#">php Developement</a>

                     </div>
                  </div>

                  <div class="col" id="useful-links">
                     <h3>Links</h3>
                     <div class="links">
                        <a href="about.php">About</a>
                        <a href="contactus.php">Contact Us</a>
                        <a href="Result/our portfolio/index.php">Developer</a>
                        <a href="#">Help & Center</a>
                     </div>
                  </div>

                  <div class="col" id="contact">
                      <h3>Contact</h3>
                      <div class="contact-details">
                         <i class="fa fa-location"></i>
                         <p>Charbagh  Lucknow <br><br> UP , INDIA</p>
                      </div><br>
                      <div class="contact-details">
                         <i class="fa fa-phone" style="transform: rotate(90deg);"></i>+91-7525818779<br><br>
                         <i class="fa fa-phone" style="transform: rotate(90deg);"></i>+91-6390752083
                      </div>
                  </div>
            </div>

            

        </div>
     </footer>
<script type="text/javascript" src="js/home.js"></script>

</body>
</html>

